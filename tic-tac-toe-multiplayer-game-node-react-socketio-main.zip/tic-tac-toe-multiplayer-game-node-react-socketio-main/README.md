This repo contains code for multiplayer tic tac toe game where i used react , node-js and socketio
